/* NOVYX native bridge. Loaded after the app. Does nothing in a normal browser.
   Adds: Android back button, status bar, splash hide, and reliable external links. */
(function () {
  'use strict';
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var P = C.Plugins || {};

  /* Status bar: dark bar matching the app, light icons, content below it. */
  try {
    if (P.StatusBar) {
      P.StatusBar.setOverlaysWebView({ overlay: false });
      P.StatusBar.setStyle({ style: 'DARK' });
      P.StatusBar.setBackgroundColor({ color: '#070707' });
    }
  } catch (e) {}

  /* Splash: hide once the app has drawn. */
  try { if (P.SplashScreen) setTimeout(function () { P.SplashScreen.hide(); }, 300); } catch (e) {}

  /* Small "press back again" message, styled like the app. */
  var tip;
  function say(msg) {
    if (!tip) {
      tip = document.createElement('div');
      tip.setAttribute('role', 'status');
      tip.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:calc(96px + env(safe-area-inset-bottom,0px));' +
        'z-index:90;background:#1b1915;color:#F3EFE6;border:1px solid #C9A24B;padding:10px 16px;font:500 12px "DM Mono",monospace;' +
        'letter-spacing:.06em;max-width:86vw;text-align:center';
      document.body.appendChild(tip);
    }
    tip.textContent = msg; tip.style.display = 'block';
    clearTimeout(tip._t); tip._t = setTimeout(function () { tip.style.display = 'none'; }, 1800);
  }

  /* Back button: close product sheet -> go to Home -> press twice to exit. */
  var lastBack = 0;
  try {
    if (P.App) P.App.addListener('backButton', function () {
      var scrim = document.getElementById('scrim');
      if (scrim && !scrim.hidden) { scrim.click(); return; }        /* closes the product sheet */
      var route = (location.hash || '#home').slice(1);
      if (route && route !== 'home') { location.hash = '#home'; return; }
      var now = Date.now();
      if (now - lastBack < 1800) { P.App.exitApp(); return; }
      lastBack = now; say('Press back again to exit NOVYX');
    });
  } catch (e) {}

  /* External links (WhatsApp, Facebook, TikTok, Instagram, website) open outside the app,
     so the shop never gets replaced by another page. */
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (!/^https?:\/\//i.test(href)) return;
    ev.preventDefault();
    try { window.open(href, '_blank'); } catch (e) { location.href = href; }
  }, true);
})();
