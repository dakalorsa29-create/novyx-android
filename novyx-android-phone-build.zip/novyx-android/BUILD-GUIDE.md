# NOVYX Android app: build guide

App name **NOVYX** · Android ID **za.novyx.app** · built with Capacitor 7.
The app itself (`www/index.html`) is your NOVYX app unchanged: same design, products, prices, photos, cart, AI Creation Studio and WhatsApp ordering.

**Status:** this project has NOT been built into an APK yet. The APK is built on your computer by following the steps below.

## What you need (one time)
1. **Node.js 20 or newer (LTS)**: https://nodejs.org
2. **Android Studio** (latest): https://developer.android.com/studio. It includes the Java and Android tools. On first launch, accept the licences and let it install the Android SDK.
3. An internet connection for the first setup (it downloads Capacitor, the fonts and the Android tools).

## Step 1: Set up the project
Unzip `novyx-android.zip`. Open a terminal (Windows: right-click inside the folder → "Open in Terminal"; Mac: Terminal) **inside the novyx-android folder**, then run:

```
npm install
npm run setup
```

`npm run setup` does everything automatically:
- downloads the 3 fonts into `www/fonts` so the app works offline
- creates the `android/` project
- applies the NOVYX icon, splash screen, dark status bar, WhatsApp/link permissions
- copies the app into the Android project

If it stops with an error, read the message, fix the cause (usually internet) and run `npm run setup` again. It is safe to repeat.

## Step 2: Open it in Android Studio
```
npm run open
```
Android Studio opens the `android` folder. Wait until the progress bar at the bottom finishes ("Gradle sync"). The first time can take 5 to 15 minutes. If it asks to install an Android SDK platform or update Gradle, click the install or update link.

## Step 3: Build a test APK (to install on your phone)
In Android Studio: **Build → Build APK(s)**. When it finishes, click **locate** in the pop-up. The file is:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Step 4: Install on your phone
- Send `app-debug.apk` to your phone (WhatsApp, email, USB cable or Google Drive), open it, and allow "Install unknown apps" when asked.
- Or plug in the phone with USB debugging on and press the green **Run** button in Android Studio.

## Step 5: Check these on the phone
- The NOVYX icon appears in your app list and the black splash screen shows the logo.
- All 8 tabs, the Ladies' Collection, product sheets, photos, prices and the AI Creation Studio look the same as the web version.
- Add items to the cart, close the app completely, reopen it: the cart is still there.
- "Send order on WhatsApp", the header WhatsApp button, and the Contact links (Facebook, TikTok, Instagram, website) open outside the app.
- Back button: closes a product sheet, then goes Home, then "press back again" exits.
- Turn on airplane mode: the app, fonts and photos still load (only the links need internet).
- In the AI Studio, attach a photo from the gallery.

## Step 6: Release version for the Google Play Store
Play Store needs a signed **AAB**, not the test APK.
1. In Android Studio: **Build → Generate Signed Bundle / APK → Android App Bundle**.
2. Click **Create new** keystore, choose a password, and **keep the keystore file and passwords safe forever**. If you lose them you cannot update the app. Never share them or put them online.
3. Choose **release** and finish. The `.aab` is created in `android/app/release/`.
4. Upload it in the Google Play Console (one-time US$25 developer fee). Use the files in `store-assets/` (512×512 icon and 1024×500 feature graphic).
To share a **signed APK** outside the Play Store, choose APK instead of Android App Bundle in the same wizard.

## Changing the app later
Edit `www/index.html` (prices, products, text), then run `npm run sync` and rebuild in Android Studio. Increase `versionCode` and `versionName` in `android/app/build.gradle` before every Play Store update.

## What is in this folder
| Path | What it is |
|---|---|
| `www/index.html` | The NOVYX app (HTML, CSS, JavaScript: unchanged) |
| `www/photos/` | All 110 photos, same folders as before |
| `www/fonts/` | Fonts, filled in by `npm run setup` |
| `www/native.js` | Android extras: back button, status bar, splash, external links |
| `capacitor.config.json` | App name NOVYX, ID za.novyx.app, splash and status bar settings |
| `package.json` | The list of tools Capacitor needs |
| `setup.js` | The one-command setup described above |
| `android-overlay/` | NOVYX launcher icons, splash images, applied by setup |
| `resources/` | Master icon (1024), icon foreground, splash (2732) and the source logos |
| `store-assets/` | Play Store icon and feature graphic |
| `android/` | Created by `npm run setup` |

## Notes
- The logo files I had are small (800 px wide), so the icon and splash are made from an enlarged copy. They look clean on phones, but for the sharpest result replace `resources/icon.png` and `resources/splash.png` with versions made from your original logo file and run `npm run setup` again after deleting the `android` folder.
- Orders still go to WhatsApp 072 142 3341 as a message. No payments are processed in the app.
- Prices in the app have not been changed. Still open: embroidered tee base price (app R400, one older poster R350) and the Forest Edition / Pink Dream cap prices.
